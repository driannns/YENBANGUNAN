@props(['active'])

@php
$classes = ($active ?? false)
            ? 'font-d-din inline-flex items-center px-1 pt-1 border-b-2 border-white text-lg font-black leading-5 text-white focus:outline-none focus:border-indigo-700 transition duration-150 ease-in-out'
            : 'font-d-din inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-lg font-black leading-5 text-white hover:text-[#e05534] hover:border-gray-300 focus:outline-none focus:text-gray-700 focus:border-gray-300 transition duration-150 ease-in-out';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>
