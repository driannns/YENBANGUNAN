<?php

namespace App\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Blade::if('admin', function () {
            return auth()->check() && auth()->user()->is_admin && !auth()->user()->is_manager;
        });

        Blade::if('manager', function () {
            return auth()->check() && auth()->user()->is_admin && auth()->user()->is_manager;
        });
    }
}
