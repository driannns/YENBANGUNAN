<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Generated from the WordPress export by database/seeders/generator/gen_blog_seeders.py.
 * Part 8 of 10. Do not edit by hand — regenerate instead.
 */
class BlogPart8 extends Seeder
{
    public function run(): void
    {
        $posts = [
            [
                'title' => 'Lampu Plafon 9 Watt Inbow Lingkaran (INLite)',
                'slug' => '2026/05/21/lampu-plafon-9-watt-inbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-9-watt-inbow-lingkaran-inlite.jpg" alt="" class="wp-image-4915" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 9 Watt Inbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain slim dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain slim dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-9-watt-inbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:08:33',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Sorot Bawah Air 100 Watt (INLite)',
                'slug' => '2026/05/21/lampu-sorot-bawah-air-100-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-sorot-bawah-air-100-watt-inlite.jpg" alt="" class="wp-image-4679" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Sorot Bawah Air 100 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>',
                'image_path' => '/blog/lampu-sorot-bawah-air-100-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:08:58',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Sorot Bawah Air 20 Watt (INLite)',
                'slug' => '2026/05/21/lampu-sorot-bawah-air-20-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-sorot-bawah-air-20-watt-inlite.jpg" alt="" class="wp-image-4676" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Sorot Bawah Air 20 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>',
                'image_path' => '/blog/lampu-sorot-bawah-air-20-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:09:33',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Sorot Bawah Air 200 Watt (INLite)',
                'slug' => '2026/05/21/lampu-sorot-bawah-air-200-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-sorot-bawah-air-200-watt-inlite.jpg" alt="" class="wp-image-4680" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Sorot Bawah Air 200 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>',
                'image_path' => '/blog/lampu-sorot-bawah-air-200-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:09:51',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Sorot Bawah Air 30 Watt (INLite)',
                'slug' => '2026/05/21/lampu-sorot-bawah-air-30-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-sorot-bawah-air-30-watt-inlite.jpg" alt="" class="wp-image-4677" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Sorot Bawah Air 30 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>',
                'image_path' => '/blog/lampu-sorot-bawah-air-30-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:10:11',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Sorot Bawah Air 50 Watt (INLite)',
                'slug' => '2026/05/21/lampu-sorot-bawah-air-50-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-sorot-bawah-air-50-watt-inlite.jpg" alt="" class="wp-image-5012" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Sorot Bawah Air 50 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu sorot LED INLite merupakan solusi pencahayaan berintensitas tinggi yang dirancang untuk kebutuhan penerangan area luar ruang maupun interior yang memerlukan sorotan cahaya kuat dan fokus. Dilengkapi sistem pendingin pasif yang efisien serta perlindungan tahan cuaca, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan, baik di dalam maupun luar ruangan. Menghasilkan cahaya yang terang, stabil, dan terfokus, lampu sorot ini sangat ideal digunakan untuk penerangan fasad bangunan, area taman, lapangan, papan reklame, panggung, hingga berbagai kebutuhan pencahayaan dekoratif dan fungsional skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang kuat, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan eksterior dan interior modern di lapangan.</p>',
                'image_path' => '/blog/lampu-sorot-bawah-air-50-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:01:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu TL LED 18 Watt (INLite)',
                'slug' => '2026/05/21/lampu-tl-led-18-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-tl-led-18-watt-inlite.jpg" alt="" class="wp-image-5009" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu TL LED 18 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu TL LED berbentuk tabung merupakan pengganti modern untuk lampu neon konvensional yang dirancang untuk memberikan pencahayaan lebih terang, stabil, dan hemat energi. Dengan teknologi LED terkini, lampu ini menghasilkan cahaya merata di sepanjang tabung tanpa kedip, lebih aman untuk mata, dan memiliki umur pakai yang jauh lebih panjang dibandingkan lampu neon biasa. Sangat cocok digunakan pada berbagai area seperti rumah, kantor, toko, gudang, sekolah, hingga fasilitas umum yang membutuhkan pencahayaan merata, efisien, dan tahan lama.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan fungsional di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu TL LED berbentuk tabung merupakan pengganti modern untuk lampu neon konvensional yang dirancang untuk memberikan pencahayaan lebih terang, stabil, dan hemat energi. Dengan teknologi LED terkini, lampu ini menghasilkan cahaya merata di sepanjang tabung tanpa kedip, lebih aman untuk mata, dan memiliki umur pakai yang jauh lebih panjang dibandingkan lampu neon biasa. Sangat cocok digunakan pada berbagai area seperti rumah, kantor, toko, gudang, sekolah, hingga fasilitas umum yang membutuhkan pencahayaan merata, efisien, dan tahan lama.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pencahayaan fungsional di lapangan.</p>',
                'image_path' => '/blog/lampu-tl-led-18-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:01:53',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lubang Stop Kontak + Saklar 1 Lubang (Broco)',
                'slug' => '2026/05/21/lubang-stop-kontak-saklar-1-lubang-broco',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lubang-stop-kontak-saklar-1-lubang-broco.jpg" alt="" class="wp-image-4891" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lubang Stop Kontak + Saklar 1 Lubang (Broco) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Perangkat listrik kombinasi stop kontak dan saklar dalam satu unit yang dirancang untuk memberikan kemudahan instalasi dan penggunaan kelistrikan sehari-hari. Dengan desain yang kompak dan rapi, produk ini mengintegrasikan fungsi stop kontak dan saklar dalam satu lubang, sehingga menghemat ruang dinding dan mempermudah pemasangan. Dibuat dari material berkualitas yang aman, kuat, dan tahan terhadap penggunaan jangka panjang, sehingga cocok digunakan pada instalasi listrik rumah tinggal, ruko, kantor, maupun berbagai bangunan komersial lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang aman, praktis, dan berkualitas untuk mendukung kebutuhan instalasi listrik modern.</p>
</div>
</div>',
                'description' => '<p>Perangkat listrik kombinasi stop kontak dan saklar dalam satu unit yang dirancang untuk memberikan kemudahan instalasi dan penggunaan kelistrikan sehari-hari. Dengan desain yang kompak dan rapi, produk ini mengintegrasikan fungsi stop kontak dan saklar dalam satu lubang, sehingga menghemat ruang dinding dan mempermudah pemasangan. Dibuat dari material berkualitas yang aman, kuat, dan tahan terhadap penggunaan jangka panjang, sehingga cocok digunakan pada instalasi listrik rumah tinggal, ruko, kantor, maupun berbagai bangunan komersial lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang aman, praktis, dan berkualitas untuk mendukung kebutuhan instalasi listrik modern.</p>',
                'image_path' => '/blog/lubang-stop-kontak-saklar-1-lubang-broco.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:02:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 4 A',
                'slug' => '2026/05/21/mcb-1-phase-4-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-4-a.jpg" alt="" class="wp-image-4879" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 4 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-4-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:02:55',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 6 A',
                'slug' => '2026/05/21/mcb-1-phase-6-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-6-a.jpg" alt="" class="wp-image-4878" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 6 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-6-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:03:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 2 A',
                'slug' => '2026/05/21/mcb-1-phase-2-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-2-a.jpg" alt="" class="wp-image-4880" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 2 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-2-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:03:37',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 10 A',
                'slug' => '2026/05/21/mcb-1-phase-10-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-10-a.jpg" alt="" class="wp-image-4877" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 10 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-10-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:04:00',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 16 A',
                'slug' => '2026/05/21/mcb-1-phase-16-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-16-a.jpg" alt="" class="wp-image-4876" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 16 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-16-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:04:21',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 20 A',
                'slug' => '2026/05/21/mcb-1-phase-20-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-20-a.jpg" alt="" class="wp-image-4875" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 20 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-20-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:05:26',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 25 A',
                'slug' => '2026/05/21/mcb-1-phase-25-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-25-a.jpg" alt="" class="wp-image-4874" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 25 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-25-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:05:48',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 32 A',
                'slug' => '2026/05/21/mcb-1-phase-32-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-32-a.jpg" alt="" class="wp-image-4873" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 32 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-32-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:06:08',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 50 A',
                'slug' => '2026/05/21/mcb-1-phase-50-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-50-a.jpg" alt="" class="wp-image-4872" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 50 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-50-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:06:27',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 1 Phase 60 A',
                'slug' => '2026/05/21/mcb-1-phase-60-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-1-phase-60-a.jpg" alt="" class="wp-image-4871" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 1 Phase 60 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 1 phase merupakan perangkat pengaman instalasi listrik yang berfungsi untuk melindungi sistem kelistrikan dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan mekanisme kerja otomatis, MCB akan memutus aliran listrik secara cepat saat terjadi gangguan, sehingga membantu mencegah kerusakan pada instalasi maupun peralatan listrik. Produk ini sangat cocok digunakan pada instalasi listrik rumah tinggal, toko, ruko, kantor, maupun bangunan dengan sistem listrik 1 phase, serta memberikan keamanan dan keandalan yang lebih optimal dalam penggunaan listrik sehari-hari.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, berkualitas, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-1-phase-60-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:06:47',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 4 A',
                'slug' => '2026/05/21/mcb-3-phase-4-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-4-a.jpg" alt="" class="wp-image-4870" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 4 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-4-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:07:08',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 6 A',
                'slug' => '2026/05/21/mcb-3-phase-6-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-6-a.jpg" alt="" class="wp-image-4869" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 6 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-6-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:07:29',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 10 A',
                'slug' => '2026/05/21/mcb-3-phase-10-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-10-a.jpg" alt="" class="wp-image-4868" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 10 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-10-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:07:51',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 16 A',
                'slug' => '2026/05/21/mcb-3-phase-16-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-16-a.jpg" alt="" class="wp-image-4867" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 16 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-16-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:08:10',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 20 A',
                'slug' => '2026/05/21/mcb-3-phase-20-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-20-a.jpg" alt="" class="wp-image-4866" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 20 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-20-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:08:30',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 25 A',
                'slug' => '2026/05/21/mcb-3-phase-25-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-25-a.jpg" alt="" class="wp-image-4865" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 25 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-25-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:08:49',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 32 A',
                'slug' => '2026/05/21/mcb-3-phase-32-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-32-a.jpg" alt="" class="wp-image-4864" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 32 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-32-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:09:09',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 50 A',
                'slug' => '2026/05/21/mcb-3-phase-50-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-50-a.jpg" alt="" class="wp-image-4863" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 50 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-50-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:09:57',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'MCB 3 Phase 60 A',
                'slug' => '2026/05/21/mcb-3-phase-60-a',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/mcb-3-phase-60-a.jpg" alt="" class="wp-image-4862" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">MCB 3 Phase 60 A &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Miniature Circuit Breaker (MCB) 3 phase merupakan perangkat pengaman instalasi listrik yang dirancang khusus untuk melindungi sistem kelistrikan tiga phase dari risiko arus berlebih (overload) dan korsleting (short circuit). Dengan sistem pemutusan otomatis yang responsif, MCB ini membantu menjaga kestabilan dan keamanan aliran listrik sehingga dapat mencegah kerusakan pada peralatan maupun instalasi listrik secara keseluruhan. Produk ini sangat ideal digunakan pada instalasi industri, panel listrik, mesin-mesin berdaya besar, gedung komersial, hingga berbagai bangunan dengan kebutuhan daya tinggi yang membutuhkan sistem proteksi listrik yang andal.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan perangkat kelistrikan yang aman, kuat, dan berkualitas untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/mcb-3-phase-60-a.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 22:10:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 6 inch',
                'slug' => '2026/05/21/pipa-aw-6-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-6-inch.jpg" alt="" class="wp-image-4989" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 6 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-6-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:10:40',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 1 1/2 inch',
                'slug' => '2026/05/21/pipa-aw-1-1-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-1-1_2-inch-1.jpg" alt="" class="wp-image-5007" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 1 1/2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-1-1_2-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:11:01',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 1 1/2 inch (Wavin)',
                'slug' => '2026/05/21/pipa-aw-1-1-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-1-1_2-inch-wavin-1.jpg" alt="" class="wp-image-5008" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 1 1/2 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-1-1_2-inch-wavin-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:11:22',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 1 1/4 inch',
                'slug' => '2026/05/21/pipa-aw-1-1-4-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-1-1_4-inch-1.jpg" alt="" class="wp-image-5005" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 1 1/4 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-1-1_4-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:11:44',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 1 1/4 inch (Wavin)',
                'slug' => '2026/05/21/pipa-aw-1-1-4-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-1-1_4-inch-wavin-1.jpg" alt="" class="wp-image-5006" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 1 1/4 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-1-1_4-inch-wavin-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:12:06',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 1/2 inch',
                'slug' => '2026/05/21/pipa-aw-1-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-1_2-inch-1.jpg" alt="" class="wp-image-5003" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 1/2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-1_2-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:12:26',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 1/2 inch (Wavin)',
                'slug' => '2026/05/21/pipa-aw-1-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-1_2-inch-wavin-1.jpg" alt="" class="wp-image-5004" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 1/2 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-1_2-inch-wavin-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-21 22:12:46',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 10 inch',
                'slug' => '2026/05/22/pipa-aw-10-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-10-inch.jpg" alt="" class="wp-image-4987" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 10 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-10-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:37:35',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 2 1/2 inch',
                'slug' => '2026/05/22/pipa-aw-2-1-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-2-1_2-inch-1.jpg" alt="" class="wp-image-5001" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 2 1/2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-2-1_2-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:37:54',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 2 inch',
                'slug' => '2026/05/22/pipa-aw-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-2-inch.jpg" alt="" class="wp-image-4999" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-2-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:38:25',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 2 inch (Wavin)',
                'slug' => '2026/05/22/pipa-aw-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-2-inch-wavin.jpg" alt="" class="wp-image-5000" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 2 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-2-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:38:46',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 3 inch',
                'slug' => '2026/05/22/pipa-aw-3-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-3-inch.jpg" alt="" class="wp-image-4997" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 3 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-3-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:39:05',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 3 inch (Wavin)',
                'slug' => '2026/05/22/pipa-aw-3-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-3-inch-wavin.jpg" alt="" class="wp-image-4998" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 3 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-3-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:39:24',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 3/4 inch',
                'slug' => '2026/05/22/pipa-aw-3-4-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-3_4-inch-1.jpg" alt="" class="wp-image-4995" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 3/4 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-3_4-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:39:45',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 3/4 inch (Wavin)',
                'slug' => '2026/05/22/pipa-aw-3-4-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-3_4-inch-wavin-1.jpg" alt="" class="wp-image-4996" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 3/4 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-3_4-inch-wavin-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:40:04',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 4 inch',
                'slug' => '2026/05/22/pipa-aw-4-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-4-inch.jpg" alt="" class="wp-image-4993" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 4 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-4-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:40:59',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 4 inch (Wavin)',
                'slug' => '2026/05/22/pipa-aw-4-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-4-inch-wavin.jpg" alt="" class="wp-image-4994" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 4 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-4-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:41:19',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 5 inch',
                'slug' => '2026/05/22/pipa-aw-5-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-5-inch.jpg" alt="" class="wp-image-4991" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 5 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-5-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:41:38',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 5 inch (Wavin)',
                'slug' => '2026/05/22/pipa-aw-5-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-5-inch-wavin.jpg" alt="" class="wp-image-4992" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 5 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-5-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:41:58',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 6 inch (Wavin)',
                'slug' => '2026/05/22/pipa-aw-6-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-6-inch-wavin.jpg" alt="" class="wp-image-4990" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 6 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-6-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:42:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa AW 8 inch',
                'slug' => '2026/05/22/pipa-aw-8-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-aw-8-inch.jpg" alt="" class="wp-image-4988" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa AW 8 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas AW merupakan pipa berkualitas tinggi dengan ketebalan dinding yang lebih kuat, dirancang khusus untuk kebutuhan instalasi air bertekanan seperti saluran air bersih pada berbagai jenis bangunan. Material ini memiliki ketahanan yang sangat baik terhadap tekanan tinggi, tidak mudah bocor, serta memiliki struktur yang kokoh sehingga aman digunakan dalam jangka panjang. Dengan permukaan yang halus dan presisi ukuran yang baik, pipa ini juga memudahkan proses pemasangan serta mendukung aliran air yang lebih stabil dan efisien. Sangat cocok digunakan pada instalasi air rumah tinggal, ruko, gedung komersial, fasilitas industri, hingga berbagai proyek konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang kuat, tahan lama, dan terpercaya untuk mendukung sistem instalasi modern di lapangan.</p>',
                'image_path' => '/blog/pipa-aw-8-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:42:35',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 1 1/2 inch',
                'slug' => '2026/05/22/pipa-d-1-1-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-1-1_2-inch-1.jpg" alt="" class="wp-image-4985" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 1 1/2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-1-1_2-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:42:55',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 1 1/2 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-1-1-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-1-1_2-inch-wavin.jpg" alt="" class="wp-image-4986" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 1 1/2 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-1-1_2-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:43:14',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 1 1/4 inch',
                'slug' => '2026/05/22/pipa-d-1-1-4-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-1-1_4-inch-1.jpg" alt="" class="wp-image-4983" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 1 1/4 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-1-1_4-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:43:33',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 1 1/4 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-1-1-4-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-1-1_4-inch-wavin.jpg" alt="" class="wp-image-4985" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 1 1/4 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-1-1_4-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:43:52',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 1/2 inch',
                'slug' => '2026/05/22/pipa-d-1-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-1_2-inch-1.jpg" alt="" class="wp-image-4981" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 1/2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-1_2-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:44:11',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 1/2 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-1-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-1_2-inch-wavin.jpg" alt="" class="wp-image-4983" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 1/2 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-1_2-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:44:29',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 10 inch',
                'slug' => '2026/05/22/pipa-d-10-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-10-inch.jpg" alt="" class="wp-image-4965" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 10 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-10-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 08:44:50',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 2 1/2 inch',
                'slug' => '2026/05/22/pipa-d-2-1-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-2-1_2-inch-1.jpg" alt="" class="wp-image-4979" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 2 1/2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-2-1_2-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:32:30',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 2 1/2 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-2-1-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-2-1_2-inch-wavin.jpg" alt="" class="wp-image-4979" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 2 1/2 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-2-1_2-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:32:51',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 2 inch',
                'slug' => '2026/05/22/pipa-d-2-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-2-inch.jpg" alt="" class="wp-image-4977" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 2 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-2-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:33:30',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 2 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-2-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-2-inch-wavin.jpg" alt="" class="wp-image-4978" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 2 inch (Wavin) &#8211; Yen Bangunan Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p class="wp-block-paragraph">Pipa PVC dengan ketebalan standar (kelas D) yang cocok untuk instalasi pembuangan air tanpa tekanan seperti saluran limbah dan drainase. Ringan, mudah dipasang, dan tahan terhadap korosi untuk penggunaan jangka panjang. Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar.</p>
</div>
</div>',
                'description' => '<p class="wp-block-paragraph">Pipa PVC dengan ketebalan standar (kelas D) yang cocok untuk instalasi pembuangan air tanpa tekanan seperti saluran limbah dan drainase. Ringan, mudah dipasang, dan tahan terhadap korosi untuk penggunaan jangka panjang. Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar.</p>',
                'image_path' => '/blog/pipa-d-2-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:34:03',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 3 inch',
                'slug' => '2026/05/22/pipa-d-3-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-3-inch.jpg" alt="" class="wp-image-4975" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 3 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-3-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:34:23',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 3 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-3-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-3-inch-wavin.jpg" alt="" class="wp-image-4976" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 3 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-3-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:35:00',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 3/4 inch',
                'slug' => '2026/05/22/pipa-d-3-4-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-3_4-inch-1.jpg" alt="" class="wp-image-4973" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 3/4 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-3_4-inch-1.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:35:19',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 3/4 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-3-4-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-3_4-inch-wavin.jpg" alt="" class="wp-image-4974" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 3/4 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-3_4-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:35:38',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 4 inch',
                'slug' => '2026/05/22/pipa-d-4-inch',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-4-inch.jpg" alt="" class="wp-image-4971" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 4 inch &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-4-inch.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:35:57',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Pipa D 4 inch (Wavin)',
                'slug' => '2026/05/22/pipa-d-4-inch-wavin',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/pipa-d-4-inch-wavin.jpg" alt="" class="wp-image-4972" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Pipa D 4 inch (Wavin) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Pipa PVC kelas D merupakan solusi perpipaan yang dirancang untuk kebutuhan instalasi pembuangan air tanpa tekanan pada berbagai jenis bangunan. Dengan ketebalan standar yang sesuai untuk saluran limbah, air buangan, ventilasi, dan sistem drainase, pipa ini menawarkan kinerja yang andal serta efisiensi dalam proses instalasi. Material PVC berkualitas membuatnya ringan, mudah dipotong, dan mudah dipasang, sehingga membantu mempercepat pekerjaan konstruksi di lapangan. Selain itu, pipa ini tahan terhadap korosi, tidak mudah berkarat, dan memiliki daya tahan yang baik untuk penggunaan jangka panjang.</p>
<p>Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, gedung komersial, fasilitas umum, kawasan industri, hingga berbagai proyek konstruksi berskala besar yang membutuhkan sistem pembuangan air yang efektif dan ekonomis.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk plumbing yang berkualitas, tahan lama, dan terpercaya untuk mendukung kelancaran pembangunan di lapangan.</p>',
                'image_path' => '/blog/pipa-d-4-inch-wavin.jpg',
                'category' => 'pipa-dan-sanitasi',
                'published_at' => '2026-05-22 10:36:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        DB::table('blogs')->upsert(
            $posts,
            ['slug'],
            ['title', 'content', 'description', 'image_path', 'category', 'published_at', 'author_id', 'updated_at']
        );
    }
}
