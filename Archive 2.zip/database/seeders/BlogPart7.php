<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Generated from the WordPress export by database/seeders/generator/gen_blog_seeders.py.
 * Part 7 of 10. Do not edit by hand — regenerate instead.
 */
class BlogPart7 extends Seeder
{
    public function run(): void
    {
        $posts = [
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 2 x 0,75',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-2-x-075',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-2-x-075-1.jpg" alt="" class="wp-image-4836" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 2 x 0,75 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-2-x-075-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:52:48',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 2 x 1,5',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-2-x-15',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-2-x-15-1.jpg" alt="" class="wp-image-4835" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 2 x 1,5 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-2-x-15-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:53:38',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 2 x 2,5',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-2-x-25',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-2-x-25-1.jpg" alt="" class="wp-image-4834" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 2 x 2,5 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-2-x-25-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:53:58',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 3 x 0,75',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-3-x-075',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-3-x-075-1.jpg" alt="" class="wp-image-4833" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 3 x 0,75 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-3-x-075-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:54:18',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 3 x 1,5',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-3-x-15',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-3-x-15-1.jpg" alt="" class="wp-image-4832" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 3 x 1,5 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-3-x-15-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:54:37',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 3 x 2,5',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-3-x-25',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-3-x-25-1.jpg" alt="" class="wp-image-4831" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 3 x 2,5 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-3-x-25-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:54:57',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 4 x 0,75',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-4-x-075',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-4-x-075-1.jpg" alt="" class="wp-image-4830" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 4 x 0,75 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-4-x-075-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 02:55:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 4 x 1,5',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-4-x-15',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-4-x-15-1.jpg" alt="" class="wp-image-4828" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 4 x 1,5 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-4-x-15-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:12:35',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 4 x 2,5',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-4-x-25',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-4-x-25-1.jpg" alt="" class="wp-image-4827" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 4 x 2,5 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-4-x-25-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:12:54',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Jembo NYYHY 50 Meter 4 x 4',
                'slug' => '2026/05/17/kabel-jembo-nyyhy-50-meter-4-x-4',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-jembo-nyyhy-50-meter-4-x-4-1.jpg" alt="" class="wp-image-4623" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Jembo NYYHY 50 Meter 4 x 4 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-jembo-nyyhy-50-meter-4-x-4-1.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:13:13',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kabel Roll 6 Lubang (Broco)',
                'slug' => '2026/05/17/kabel-roll-6-lubang-broco',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kabel-roll-6-lubang-broco.jpg" alt="" class="wp-image-4624" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kabel Roll 6 Lubang (Broco) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kabel listrik fleksibel dengan inti serabut dan lapisan isolasi PVC berkualitas yang dirancang untuk memberikan kelenturan tinggi serta kemudahan dalam berbagai kebutuhan instalasi listrik ringan. Kabel ini sangat cocok digunakan untuk peralatan elektronik, sambungan listrik, perangkat rumah tangga, serta berbagai aplikasi instalasi yang membutuhkan fleksibilitas dan mobilitas dalam pemasangan. Dengan daya hantar listrik yang stabil serta karakter yang mudah dibentuk, kabel ini mendukung penggunaan sehari-hari yang aman, praktis, dan efisien pada berbagai kebutuhan kelistrikan skala kecil hingga menengah.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan yang fleksibel, aman, dan berkualitas untuk mendukung kebutuhan instalasi modern di lapangan.</p>',
                'image_path' => '/blog/kabel-roll-6-lubang-broco.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:13:35',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kayu Kaso 4 x 6',
                'slug' => '2026/05/17/kayu-kaso-4-x-6',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kayu-kaso-4-x-6.jpg" alt="" class="wp-image-4627" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kayu Kaso 4 x 6 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kayu kaso merupakan material kayu konstruksi berukuran sedang yang umum digunakan dalam berbagai pekerjaan bangunan. Material ini memiliki kekuatan struktural yang baik serta mudah diolah, sehingga sangat cocok untuk rangka atap, dudukan plafon, penyangga, hingga berbagai kebutuhan konstruksi dan pertukangan lainnya. Dengan karakter yang mudah dipotong, dibentuk, dan dipasang, kayu kaso mendukung efisiensi pekerjaan di lapangan serta memberikan hasil konstruksi yang rapi dan kokoh. Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, bangunan komersial, hingga berbagai pekerjaan konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan material kayu berkualitas yang kuat, praktis, dan siap mendukung kebutuhan pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kayu kaso merupakan material kayu konstruksi berukuran sedang yang umum digunakan dalam berbagai pekerjaan bangunan. Material ini memiliki kekuatan struktural yang baik serta mudah diolah, sehingga sangat cocok untuk rangka atap, dudukan plafon, penyangga, hingga berbagai kebutuhan konstruksi dan pertukangan lainnya. Dengan karakter yang mudah dipotong, dibentuk, dan dipasang, kayu kaso mendukung efisiensi pekerjaan di lapangan serta memberikan hasil konstruksi yang rapi dan kokoh. Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, bangunan komersial, hingga berbagai pekerjaan konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan material kayu berkualitas yang kuat, praktis, dan siap mendukung kebutuhan pembangunan di lapangan.</p>',
                'image_path' => '/blog/kayu-kaso-4-x-6.jpg',
                'category' => 'hebel-dan-bata',
                'published_at' => '2026-05-17 22:13:56',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Kayu Kaso 5 x 7',
                'slug' => '2026/05/17/kayu-kaso-5-x-7',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/kayu-kaso-5-x-7.jpg" alt="" class="wp-image-4628" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Kayu Kaso 5 x 7 &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Kayu kaso merupakan material kayu konstruksi berukuran sedang yang umum digunakan dalam berbagai pekerjaan bangunan. Material ini memiliki kekuatan struktural yang baik serta mudah diolah, sehingga sangat cocok untuk rangka atap, dudukan plafon, penyangga, hingga berbagai kebutuhan konstruksi dan pertukangan lainnya. Dengan karakter yang mudah dipotong, dibentuk, dan dipasang, kayu kaso mendukung efisiensi pekerjaan di lapangan serta memberikan hasil konstruksi yang rapi dan kokoh. Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, bangunan komersial, hingga berbagai pekerjaan konstruksi skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan material kayu berkualitas yang kuat, praktis, dan siap mendukung kebutuhan pembangunan di lapangan.</p>
</div>
</div>',
                'description' => '<p>Kayu kaso merupakan material kayu konstruksi berukuran sedang yang umum digunakan dalam berbagai pekerjaan bangunan. Material ini memiliki kekuatan struktural yang baik serta mudah diolah, sehingga sangat cocok untuk rangka atap, dudukan plafon, penyangga, hingga berbagai kebutuhan konstruksi dan pertukangan lainnya. Dengan karakter yang mudah dipotong, dibentuk, dan dipasang, kayu kaso mendukung efisiensi pekerjaan di lapangan serta memberikan hasil konstruksi yang rapi dan kokoh. Cocok digunakan pada proyek pembangunan rumah tinggal, ruko, bangunan komersial, hingga berbagai pekerjaan konstruksi skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan material kayu berkualitas yang kuat, praktis, dan siap mendukung kebutuhan pembangunan di lapangan.</p>',
                'image_path' => '/blog/kayu-kaso-5-x-7.jpg',
                'category' => 'hebel-dan-bata',
                'published_at' => '2026-05-17 22:14:15',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 12 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-12-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-12-watt-inlite.jpg" alt="" class="wp-image-5039" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 12 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-12-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:14:37',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 12 Watt (2 Free 1) (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-12-watt-2-free-1-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-12-watt-2-free-1-inlite.jpg" alt="" class="wp-image-5040" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 12 Watt (2 Free 1) (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-12-watt-2-free-1-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:29:20',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 15 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-15-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-15-watt-inlite.jpg" alt="" class="wp-image-5037" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 15 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-15-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:29:51',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 15 Watt (2 free 1) (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-15-watt-2-free-1-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-15-watt-2-free-1-inlite.jpg" alt="" class="wp-image-5038" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 15 Watt (2 free 1) (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-15-watt-2-free-1-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:30:14',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 18 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-18-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-18-watt-inlite.jpg" alt="" class="wp-image-4641" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 18 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-18-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:30:36',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 18 Watt (2 free 1) (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-18-watt-2-free-1-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-18-watt-2-free-1-inlite.jpg" alt="" class="wp-image-4640" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 18 Watt (2 free 1) (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-18-watt-2-free-1-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:31:10',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 25 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-25-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-25-watt-inlite.jpg" alt="" class="wp-image-5034" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 25 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-25-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:31:31',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 3 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-3-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-3-watt-inlite.jpg" alt="" class="wp-image-5047" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 3 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-3-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:31:52',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 5 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-5-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-5-watt-inlite.jpg" alt="" class="wp-image-5045" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 5 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-5-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:32:14',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 5 Watt (2 free 1) (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-5-watt-2-free-1-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-5-watt-2-free-1-inlite.jpg" alt="" class="wp-image-5046" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 5 Watt (2 free 1) (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-5-watt-2-free-1-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:32:38',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 7 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-7-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-7-watt-inlite.jpg" alt="" class="wp-image-5043" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 7 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-7-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:32:57',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 7 Watt (2 free 1) (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-7-watt-2-free-1-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-7-watt-2-free-1-inlite.jpg" alt="" class="wp-image-5044" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 7 Watt (2 free 1) (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-7-watt-2-free-1-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:33:16',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 9 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-9-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-9-watt-inlite.jpg" alt="" class="wp-image-5041" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 9 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-9-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:33:36',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam 9 Watt (2 free 1) (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-9-watt-2-free-1-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-9-watt-2-free-1-inlite.jpg" alt="" class="wp-image-5042" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam 9 Watt (2 free 1) (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu LED hemat energi merupakan solusi pencahayaan modern dengan tingkat efisiensi tinggi yang menghasilkan cahaya terang, stabil, dan nyaman di mata. Dilengkapi teknologi instant on tanpa delay serta sistem perlindungan panas (overheat protection), lampu ini dirancang untuk memberikan performa optimal sekaligus memperpanjang usia pemakaian. Dengan konsumsi listrik yang jauh lebih efisien hingga ±80–90% dibandingkan lampu konvensional, produk ini sangat cocok digunakan untuk kebutuhan pencahayaan indoor maupun outdoor seperti rumah tinggal, kantor, ruko, gedung komersial, hingga area umum lainnya.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk kelistrikan dan pencahayaan yang hemat energi, berkualitas, dan terpercaya untuk mendukung kebutuhan pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-9-watt-2-free-1-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:33:56',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam Kapsul 20 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-kapsul-20-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-kapsul-20-watt-inlite.jpg" alt="" class="wp-image-5033" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam Kapsul 20 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-kapsul-20-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:34:19',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam Kapsul 30 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-kapsul-30-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-kapsul-30-watt-inlite.jpg" alt="" class="wp-image-5032" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam Kapsul 30 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-kapsul-30-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:34:38',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam Kapsul 40 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-kapsul-40-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-kapsul-40-watt-inlite.jpg" alt="" class="wp-image-5031" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam Kapsul 40 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-kapsul-40-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:34:58',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Bohlam Kapsul 50 Watt (INLite)',
                'slug' => '2026/05/17/lampu-bohlam-kapsul-50-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-bohlam-kapsul-50-watt-inlite.jpg" alt="" class="wp-image-5030" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Bohlam Kapsul 50 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu bohlam kapsul merupakan lampu berukuran kecil dengan desain pin (G4/G9) yang dirancang untuk kebutuhan pencahayaan dekoratif dan interior modern. Dengan bentuk yang ringkas, lampu ini sangat cocok digunakan pada lampu hias, lampu gantung, lampu kabinet, serta berbagai aplikasi pencahayaan estetis lainnya yang membutuhkan tampilan rapi dan elegan. Menghasilkan cahaya yang terang dan fokus, lampu ini tersedia dalam pilihan LED maupun halogen yang dapat disesuaikan dengan kebutuhan efisiensi energi maupun karakter pencahayaan yang diinginkan, sehingga memberikan fleksibilitas dalam berbagai desain interior.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang variatif, berkualitas, dan mendukung kebutuhan desain serta pembangunan modern di lapangan.</p>',
                'image_path' => '/blog/lampu-bohlam-kapsul-50-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:35:18',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Dinding 3 Watt 300K Hitam / Putih (INLite)',
                'slug' => '2026/05/17/lampu-dinding-3-watt-300k-hitam-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-dinding-3-watt-300k-hitam-_-putih-inlite.jpg" alt="" class="wp-image-5029" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Dinding 3 Watt 300K Hitam / Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu dinding LED dengan desain minimalis dan modern yang dirancang untuk memberikan pencahayaan dekoratif sekaligus fungsional pada berbagai area bangunan. Menghasilkan cahaya warm white 3000K yang hangat, lembut, dan nyaman di mata, sehingga menciptakan suasana yang lebih elegan dan estetik. Lampu ini sangat cocok digunakan pada area interior maupun eksterior seperti tangga, koridor, teras, fasad rumah, dan dinding bangunan. Dilengkapi dengan teknologi hemat energi, penyalaan instan tanpa delay, serta perlindungan terhadap panas dan cuaca dengan standar IP65, menjadikannya lebih awet, aman, dan tahan lama untuk penggunaan jangka panjang.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain bangunan masa kini.</p>
<p>Varian warna:</p>
<ul>
<li>Hitam</li>
<li>Putih</li>
</ul>
</div>
</div>',
                'description' => '<p>Lampu dinding LED dengan desain minimalis dan modern yang dirancang untuk memberikan pencahayaan dekoratif sekaligus fungsional pada berbagai area bangunan. Menghasilkan cahaya warm white 3000K yang hangat, lembut, dan nyaman di mata, sehingga menciptakan suasana yang lebih elegan dan estetik. Lampu ini sangat cocok digunakan pada area interior maupun eksterior seperti tangga, koridor, teras, fasad rumah, dan dinding bangunan. Dilengkapi dengan teknologi hemat energi, penyalaan instan tanpa delay, serta perlindungan terhadap panas dan cuaca dengan standar IP65, menjadikannya lebih awet, aman, dan tahan lama untuk penggunaan jangka panjang.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain bangunan masa kini.</p>
<p>Varian warna:</p>
<ul>
<li>Hitam</li>
<li>Putih</li>
</ul>',
                'image_path' => '/blog/lampu-dinding-3-watt-300k-hitam-_-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:35:44',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Kotak 12 Watt Putih (INLite)',
                'slug' => '2026/05/17/lampu-downlight-kotak-12-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-kotak-12-watt-putih-inlite.jpg" alt="" class="wp-image-5027" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Kotak 12 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-kotak-12-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:36:06',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Kotak 16 Watt Putih (INLite)',
                'slug' => '2026/05/17/lampu-downlight-kotak-16-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-kotak-16-watt-putih-inlite.jpg" alt="" class="wp-image-5026" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Kotak 16 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-kotak-16-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:36:25',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Kotak 18 Watt Putih (INLite)',
                'slug' => '2026/05/17/lampu-downlight-kotak-18-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-kotak-18-watt-putih-inlite.jpg" alt="" class="wp-image-5025" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Kotak 18 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-kotak-18-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:36:45',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Kotak 7,5 Watt Putih (INLite)',
                'slug' => '2026/05/17/lampu-downlight-kotak-75-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-kotak-75-watt-putih-inlite.jpg" alt="" class="wp-image-5028" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Kotak 7,5 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-kotak-75-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:37:04',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Lingkaran 12 Watt Putih (INLite)',
                'slug' => '2026/05/17/lampu-downlight-lingkaran-12-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-lingkaran-12-watt-putih-inlite.jpg" alt="" class="wp-image-5023" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Lingkaran 12 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-lingkaran-12-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:37:27',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Lingkaran 16 Watt Putih (INLite)',
                'slug' => '2026/05/17/lampu-downlight-lingkaran-16-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-lingkaran-16-watt-putih-inlite.jpg" alt="" class="wp-image-5022" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Lingkaran 16 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-lingkaran-16-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-17 22:40:02',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Harga Besi 1 Batang Terbaru 2026, Jangan Sampai Salah Ukuran!',
                'slug' => '2026/05/18/harga-besi-1-batang-terbaru-2026-jangan-sampai-salah-ukuran',
                'content' => '<p><img class="alignnone size-full wp-image-4383" src="/assets/blog/harga-besi-1-batang-terbaru-2026-jangan-sampai-salah-ukuran.jpg" alt="" width="1000" height="700" /></p>
<p>Membangun rumah atau renovasi memang tidak bisa asal beli material, apalagi untuk besi beton. Banyak orang fokus mencari harga termurah, tapi lupa memastikan ukuran dan kualitasnya sesuai kebutuhan. Akibatnya, struktur bangunan bisa kurang kuat atau malah membuat biaya membengkak karena salah perhitungan.</p>
<p>Di tahun 2026, harga besi 1 batang mengalami perubahan mengikuti harga bahan baku dan distribusi material di berbagai daerah. Karena itu, penting untuk memahami jenis, ukuran, dan kisaran harga sebelum membeli.</p>
<p><strong><span dir="auto">Baca juga:</span></strong></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/"><span dir="auto">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/"><span dir="auto">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/"><span dir="auto">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</span></a></span></p>
<h2>Daftar Harga Besi 1 Batang Terbaru 2026</h2>
<p>Berikut estimasi harga besi beton per batang ukuran 12 meter yang umum digunakan untuk rumah dan bangunan kecil:</p>
<div class="TyagGW_tableContainer">
<div class="group TyagGW_tableWrapper flex flex-col-reverse w-fit">
<table class="w-fit min-w-(--thread-content-width)">
<thead>
<tr>
<th class="last:pe-10">Ukuran Besi</th>
<th class="last:pe-10">Jenis</th>
<th class="last:pe-10">Kisaran Harga</th>
</tr>
</thead>
<tbody>
<tr>
<td>Besi 6 mm</td>
<td>Polos</td>
<td>Rp28.000 - Rp32.000</td>
</tr>
<tr>
<td>Besi 8 mm</td>
<td>Polos</td>
<td>Rp40.000 - Rp48.000</td>
</tr>
<tr>
<td>Besi 10 mm</td>
<td>Polos</td>
<td>Rp65.000 - Rp76.000</td>
</tr>
<tr>
<td>Besi 12 mm</td>
<td>Polos</td>
<td>Rp90.000 - Rp111.000</td>
</tr>
<tr>
<td>Besi 13 mm</td>
<td>Ulir</td>
<td>Rp103.000 - Rp149.000</td>
</tr>
<tr>
<td>Besi 16 mm</td>
<td>Ulir</td>
<td>Rp170.000 - Rp201.000</td>
</tr>
</tbody>
</table>
</div>
</div>
<p>Harga bisa berbeda tergantung merek, lokasi pengiriman, dan apakah besi sudah standar SNI atau belum.</p>
<h2>Jangan Sampai Salah Ukuran Besi</h2>
<p>Kesalahan paling umum saat membeli besi adalah hanya melihat harga tanpa memahami fungsi ukurannya. Padahal, setiap diameter besi punya penggunaan berbeda.</p>
<h3>Besi 6-8 mm</h3>
<p>Biasanya dipakai untuk begel atau rangka ringan seperti pagar dan dak kecil.</p>
<h3>Besi 10-12 mm</h3>
<p>Sering digunakan untuk tulangan rumah 1 lantai, sloof, dan kolom praktis.</p>
<h3>Besi 13-16 mm</h3>
<p>Cocok untuk struktur yang lebih berat seperti rumah 2 lantai atau bangunan komersial kecil.</p>
<p>Semakin besar diameter besi, semakin besar juga daya tahan bebannya. Karena itu, jangan tergoda memilih ukuran kecil hanya demi menghemat budget.</p>
<h2>Tips Memilih Besi Beton yang Bagus</h2>
<p>Supaya tidak rugi saat membeli, perhatikan beberapa hal berikut:</p>
<ul>
<li>Pilih besi dengan label SNI agar kualitas lebih terjamin.</li>
<li>Cek panjang standar, biasanya 12 meter per batang.</li>
<li>Hindari besi “banci” yang diameter aslinya lebih kecil dari ukuran tertulis.</li>
<li>Pastikan permukaan besi tidak terlalu berkarat atau retak.</li>
</ul>
<p>Banyak orang baru sadar salah beli ketika proses pengecoran sudah berjalan. Padahal, mengganti material di tengah proyek justru lebih mahal.</p>
<h2>Beli Besi Bangunan Lebih Aman di Yen Bangunan</h2>
<p>Kalau Anda sedang mencari harga besi 1 batang terbaru 2026 untuk kebutuhan rumah, renovasi, atau proyek kecil, Yen Bangunan siap membantu dengan pilihan material lengkap dan berkualitas.</p>
<p>Tim dari <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> juga dapat membantu memberikan rekomendasi ukuran besi sesuai kebutuhan bangunan agar Anda tidak salah beli dan budget tetap aman.</p>',
                'description' => '<p></p>
<p>Membangun rumah atau renovasi memang tidak bisa asal beli material, apalagi untuk besi beton. Banyak orang fokus mencari harga termurah, tapi lupa memastikan ukuran dan kualitasnya sesuai kebutuhan. Akibatnya, struktur bangunan bisa kurang kuat atau malah membuat biaya membengkak karena salah perhitungan.</p>
<p>Di tahun 2026, harga besi 1 batang mengalami perubahan mengikuti harga bahan baku dan distribusi material di berbagai daerah. Karena itu, penting untuk memahami jenis, ukuran, dan kisaran harga sebelum membeli.</p>
<p><strong>Baca juga:</strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</a></p>
<h1>Daftar Harga Besi 1 Batang Terbaru 2026</h1>
<p>Berikut estimasi harga besi beton per batang ukuran 12 meter yang umum digunakan untuk rumah dan bangunan kecil:</p>
<div class="TyagGW_tableContainer">
<div class="group TyagGW_tableWrapper flex flex-col-reverse w-fit">

Ukuran Besi
Jenis
Kisaran Harga

Besi 6 mm
Polos
Rp28.000 - Rp32.000

Besi 8 mm
Polos
Rp40.000 - Rp48.000

Besi 10 mm
Polos
Rp65.000 - Rp76.000

Besi 12 mm
Polos
Rp90.000 - Rp111.000

Besi 13 mm
Ulir
Rp103.000 - Rp149.000

Besi 16 mm
Ulir
Rp170.000 - Rp201.000

</div>
</div>
<p>Harga bisa berbeda tergantung merek, lokasi pengiriman, dan apakah besi sudah standar SNI atau belum.</p>
<h1>Jangan Sampai Salah Ukuran Besi</h1>
<p>Kesalahan paling umum saat membeli besi adalah hanya melihat harga tanpa memahami fungsi ukurannya. Padahal, setiap diameter besi punya penggunaan berbeda.</p>
<h1>Besi 6-8 mm</h1>
<p>Biasanya dipakai untuk begel atau rangka ringan seperti pagar dan dak kecil.</p>
<h1>Besi 10-12 mm</h1>
<p>Sering digunakan untuk tulangan rumah 1 lantai, sloof, dan kolom praktis.</p>
<h1>Besi 13-16 mm</h1>
<p>Cocok untuk struktur yang lebih berat seperti rumah 2 lantai atau bangunan komersial kecil.</p>
<p>Semakin besar diameter besi, semakin besar juga daya tahan bebannya. Karena itu, jangan tergoda memilih ukuran kecil hanya demi menghemat budget.</p>
<h1>Tips Memilih Besi Beton yang Bagus</h1>
<p>Supaya tidak rugi saat membeli, perhatikan beberapa hal berikut:</p>
<ul>
<li>Pilih besi dengan label SNI agar kualitas lebih terjamin.</li>
<li>Cek panjang standar, biasanya 12 meter per batang.</li>
<li>Hindari besi “banci” yang diameter aslinya lebih kecil dari ukuran tertulis.</li>
<li>Pastikan permukaan besi tidak terlalu berkarat atau retak.</li>
</ul>
<p>Banyak orang baru sadar salah beli ketika proses pengecoran sudah berjalan. Padahal, mengganti material di tengah proyek justru lebih mahal.</p>
<h1>Beli Besi Bangunan Lebih Aman di Yen Bangunan</h1>
<p>Kalau Anda sedang mencari harga besi 1 batang terbaru 2026 untuk kebutuhan rumah, renovasi, atau proyek kecil, Yen Bangunan siap membantu dengan pilihan material lengkap dan berkualitas.</p>
<p>Tim dari <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> juga dapat membantu memberikan rekomendasi ukuran besi sesuai kebutuhan bangunan agar Anda tidak salah beli dan budget tetap aman.</p>',
                'image_path' => '/blog/harga-besi-1-batang-terbaru-2026-jangan-sampai-salah-ukuran.jpg',
                'category' => null,
                'published_at' => '2026-05-18 21:42:33',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Harga Kanal C Terbaru 2026 dan Faktor yang Mempengaruhinya',
                'slug' => '2026/05/19/harga-kanal-c-terbaru-2026-dan-faktor-yang-mempengaruhinya',
                'content' => '<p><img class="alignnone size-full wp-image-4389" src="/assets/blog/harga-kanal-c-terbaru-2026-dan-faktor-yang-mempengaruhinya.jpg" alt="" width="1000" height="700" /></p>
<p>Saat membangun rumah, gudang, atau renovasi atap, banyak orang mulai beralih menggunakan Kanal C karena lebih ringan, praktis, dan tahan lama. Material ini sering dipakai untuk rangka atap baja ringan, plafon, hingga struktur tambahan bangunan. Di tahun 2026, harga Kanal C mengalami perubahan mengikuti kondisi pasar bahan bangunan dan harga baja global.</p>
<p>Secara umum, harga Kanal C terbaru 2026 berada di kisaran Rp68 ribuan hingga Rp95 ribuan per batang tergantung ukuran, ketebalan, dan jenis materialnya. Kanal C dengan ketebalan 0,70 mm hingga 0,75 mm masih menjadi pilihan favorit karena dianggap seimbang antara kekuatan dan harga.</p>
<p><strong><span dir="auto">Baca juga:</span></strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/"><span dir="auto">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</span></a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/"><span dir="auto">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</span></a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/"><span dir="auto">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</span></a></p>
<h2>Apa Itu Kanal C?</h2>
<p>Kanal C adalah material baja ringan berbentuk huruf “C” yang digunakan sebagai struktur penopang. Material ini terkenal karena bobotnya ringan namun tetap kuat menopang beban. Dibanding kayu, Kanal C lebih tahan rayap, tidak mudah lapuk, dan pemasangannya lebih cepat.</p>
<p>Untuk rumah tinggal, Kanal C biasanya digunakan pada rangka atap karena lebih efisien dalam jangka panjang. Banyak tukang dan kontraktor juga mulai merekomendasikan material ini karena perawatannya minim.</p>
<h2>Faktor yang Mempengaruhi Harga Kanal C 2026</h2>
<p>Harga Kanal C tidak selalu sama di setiap toko bangunan. Ada beberapa faktor yang membuat harganya bisa naik atau turun.</p>
<h3>1. Ketebalan Material</h3>
<p>Semakin tebal Kanal C, semakin tinggi harganya. Kanal C 0,75 mm tentu lebih mahal dibanding 0,45 mm karena daya tahannya lebih baik.</p>
<h3>2. Jenis Lapisan Baja</h3>
<p>Kanal C galvanis dan galvalum memiliki harga berbeda. Galvalum biasanya lebih tahan korosi sehingga banyak dipilih untuk area lembap atau dekat pantai.</p>
<h3>3. Harga Baja Global</h3>
<p>Karena bahan dasarnya berasal dari baja, perubahan harga baja dunia ikut memengaruhi harga Kanal C di Indonesia.</p>
<h3>4. Lokasi Pengiriman</h3>
<p>Harga di kota besar bisa berbeda dengan daerah lain karena biaya distribusi dan ongkos kirim.</p>
<h2>Tips Memilih Kanal C untuk Rumah</h2>
<p>Bagi orang awam, memilih Kanal C sering terasa membingungkan. Cara paling aman adalah menyesuaikan dengan kebutuhan bangunan. Untuk rumah tinggal standar, ketebalan 0,70 mm biasanya sudah cukup kuat. Pastikan juga membeli dari toko bangunan terpercaya agar mendapatkan material asli dan sesuai spesifikasi.</p>
<p>Jika masih bingung menentukan ukuran atau kebutuhan proyek, Anda bisa berkonsultasi langsung dengan tim dari <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> untuk mendapatkan rekomendasi material yang sesuai budget dan kebutuhan bangunan Anda.</p>',
                'description' => '<p></p>
<p>Saat membangun rumah, gudang, atau renovasi atap, banyak orang mulai beralih menggunakan Kanal C karena lebih ringan, praktis, dan tahan lama. Material ini sering dipakai untuk rangka atap baja ringan, plafon, hingga struktur tambahan bangunan. Di tahun 2026, harga Kanal C mengalami perubahan mengikuti kondisi pasar bahan bangunan dan harga baja global.</p>
<p>Secara umum, harga Kanal C terbaru 2026 berada di kisaran Rp68 ribuan hingga Rp95 ribuan per batang tergantung ukuran, ketebalan, dan jenis materialnya. Kanal C dengan ketebalan 0,70 mm hingga 0,75 mm masih menjadi pilihan favorit karena dianggap seimbang antara kekuatan dan harga.</p>
<p><strong>Baca juga:</strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</a></p>
<h1>Apa Itu Kanal C?</h1>
<p>Kanal C adalah material baja ringan berbentuk huruf “C” yang digunakan sebagai struktur penopang. Material ini terkenal karena bobotnya ringan namun tetap kuat menopang beban. Dibanding kayu, Kanal C lebih tahan rayap, tidak mudah lapuk, dan pemasangannya lebih cepat.</p>
<p>Untuk rumah tinggal, Kanal C biasanya digunakan pada rangka atap karena lebih efisien dalam jangka panjang. Banyak tukang dan kontraktor juga mulai merekomendasikan material ini karena perawatannya minim.</p>
<h1>Faktor yang Mempengaruhi Harga Kanal C 2026</h1>
<p>Harga Kanal C tidak selalu sama di setiap toko bangunan. Ada beberapa faktor yang membuat harganya bisa naik atau turun.</p>
<h1>1. Ketebalan Material</h1>
<p>Semakin tebal Kanal C, semakin tinggi harganya. Kanal C 0,75 mm tentu lebih mahal dibanding 0,45 mm karena daya tahannya lebih baik.</p>
<h1>2. Jenis Lapisan Baja</h1>
<p>Kanal C galvanis dan galvalum memiliki harga berbeda. Galvalum biasanya lebih tahan korosi sehingga banyak dipilih untuk area lembap atau dekat pantai.</p>
<h1>3. Harga Baja Global</h1>
<p>Karena bahan dasarnya berasal dari baja, perubahan harga baja dunia ikut memengaruhi harga Kanal C di Indonesia.</p>
<h1>4. Lokasi Pengiriman</h1>
<p>Harga di kota besar bisa berbeda dengan daerah lain karena biaya distribusi dan ongkos kirim.</p>
<h1>Tips Memilih Kanal C untuk Rumah</h1>
<p>Bagi orang awam, memilih Kanal C sering terasa membingungkan. Cara paling aman adalah menyesuaikan dengan kebutuhan bangunan. Untuk rumah tinggal standar, ketebalan 0,70 mm biasanya sudah cukup kuat. Pastikan juga membeli dari toko bangunan terpercaya agar mendapatkan material asli dan sesuai spesifikasi.</p>
<p>Jika masih bingung menentukan ukuran atau kebutuhan proyek, Anda bisa berkonsultasi langsung dengan tim dari <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> untuk mendapatkan rekomendasi material yang sesuai budget dan kebutuhan bangunan Anda.</p>',
                'image_path' => '/blog/harga-kanal-c-terbaru-2026-dan-faktor-yang-mempengaruhinya.jpg',
                'category' => null,
                'published_at' => '2026-05-19 16:05:08',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Perbedaan Expanded Metal dan Wiremesh, Mana yang Lebih Cocok?',
                'slug' => '2026/05/19/perbedaan-expanded-metal-dan-wiremesh-mana-yang-lebih-cocok',
                'content' => '<p><img class="alignnone size-full wp-image-4394" src="/assets/blog/perbedaan-expanded-metal-dan-wiremesh-mana-yang-lebih-cocok.jpg" alt="" width="1000" height="700" /></p>
<p>Saat mencari material bangunan, banyak orang awam sering bingung membedakan Expanded Metal dan Wiremesh. Sekilas keduanya memang terlihat mirip karena sama-sama berbentuk lembaran besi berjaring. Padahal, fungsi dan penggunaannya cukup berbeda.</p>
<p>Memahami perbedaan keduanya penting supaya Anda tidak salah membeli material untuk proyek rumah maupun bangunan lainnya.</p>
<p><strong><span dir="auto">Baca juga:</span></strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/"><span dir="auto">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</span></a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/"><span dir="auto">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</span></a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/"><span dir="auto">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</span></a></p>
<h2>Apa Itu Expanded Metal?</h2>
<p><img class="alignnone size-full wp-image-4394" src="/assets/blog/perbedaan-expanded-metal-dan-wiremesh-mana-yang-lebih-cocok.jpg" alt="" width="1000" height="700" /></p>
<p>Expanded Metal adalah lembaran plat besi yang disayat dan ditarik hingga membentuk pola berlubang seperti jaring. Material ini terkenal kuat, tidak mudah patah, dan sering digunakan untuk pagar, tangga, pelindung mesin, hingga dekorasi industrial.</p>
<p>Karena bentuknya kokoh, Expanded Metal juga sering dipakai pada area yang membutuhkan sirkulasi udara dan keamanan sekaligus.</p>
<h2>Apa Itu Wiremesh?</h2>
<p><img class="alignnone size-full wp-image-4395" src="/assets/blog/wiremesh-2.jpg" alt="" width="1000" height="580" /></p>
<p>Wiremesh adalah rangkaian kawat baja yang disusun seperti anyaman kotak dan dilas pada tiap titik pertemuan. Material ini paling sering digunakan sebagai tulangan beton untuk lantai, jalan, dak rumah, dan cor bangunan.</p>
<p>Wiremesh membantu proses pengecoran jadi lebih cepat dibanding merakit besi beton manual satu per satu.</p>
<h2>Perbedaan Expanded Metal dan Wiremesh</h2>
<h3>1. Fungsi Utama</h3>
<p>Expanded Metal lebih sering digunakan untuk kebutuhan pelindung atau finishing bangunan. Sementara Wiremesh fokus sebagai penguat struktur beton.</p>
<h3>2. Bentuk Material</h3>
<p>Expanded Metal berasal dari lembaran plat utuh yang disayat. Sedangkan Wiremesh dibuat dari susunan kawat baja yang dilas.</p>
<h3>3. Kekuatan dan Fleksibilitas</h3>
<p>Expanded Metal terkenal lebih kokoh terhadap tekanan dan benturan. Wiremesh unggul dalam distribusi beban pada beton sehingga cocok untuk konstruksi lantai atau jalan.</p>
<h3>4. Penggunaan di Lapangan</h3>
<p>Jika Anda ingin membuat pagar minimalis, railing, atau penutup ventilasi, Expanded Metal lebih cocok. Namun untuk pengecoran rumah atau dak, Wiremesh adalah pilihan yang lebih efisien.</p>
<h2>Mana yang Lebih Cocok?</h2>
<p>Jawabannya tergantung kebutuhan proyek Anda. Untuk struktur beton, Wiremesh jelas lebih tepat. Tetapi jika fokus pada keamanan, tampilan industrial, atau sirkulasi udara, Expanded Metal lebih unggul.</p>
<p>Bagi pemilik rumah atau proyek kecil, memilih material yang tepat bisa membantu menghemat biaya sekaligus membuat bangunan lebih awet. Karena itu, jangan hanya melihat harga murah, tetapi juga fungsi materialnya.</p>
<p>Jika Anda masih ragu memilih Expanded Metal atau Wiremesh, Anda bisa berkonsultasi langsung dengan <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> agar mendapatkan material yang sesuai kebutuhan proyek dan budget Anda.</p>',
                'description' => '<p></p>
<p>Saat mencari material bangunan, banyak orang awam sering bingung membedakan Expanded Metal dan Wiremesh. Sekilas keduanya memang terlihat mirip karena sama-sama berbentuk lembaran besi berjaring. Padahal, fungsi dan penggunaannya cukup berbeda.</p>
<p>Memahami perbedaan keduanya penting supaya Anda tidak salah membeli material untuk proyek rumah maupun bangunan lainnya.</p>
<p><strong>Baca juga:</strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</a></p>
<h1>Apa Itu Expanded Metal?</h1>
<p></p>
<p>Expanded Metal adalah lembaran plat besi yang disayat dan ditarik hingga membentuk pola berlubang seperti jaring. Material ini terkenal kuat, tidak mudah patah, dan sering digunakan untuk pagar, tangga, pelindung mesin, hingga dekorasi industrial.</p>
<p>Karena bentuknya kokoh, Expanded Metal juga sering dipakai pada area yang membutuhkan sirkulasi udara dan keamanan sekaligus.</p>
<h1>Apa Itu Wiremesh?</h1>
<p></p>
<p>Wiremesh adalah rangkaian kawat baja yang disusun seperti anyaman kotak dan dilas pada tiap titik pertemuan. Material ini paling sering digunakan sebagai tulangan beton untuk lantai, jalan, dak rumah, dan cor bangunan.</p>
<p>Wiremesh membantu proses pengecoran jadi lebih cepat dibanding merakit besi beton manual satu per satu.</p>
<h1>Perbedaan Expanded Metal dan Wiremesh</h1>
<h1>1. Fungsi Utama</h1>
<p>Expanded Metal lebih sering digunakan untuk kebutuhan pelindung atau finishing bangunan. Sementara Wiremesh fokus sebagai penguat struktur beton.</p>
<h1>2. Bentuk Material</h1>
<p>Expanded Metal berasal dari lembaran plat utuh yang disayat. Sedangkan Wiremesh dibuat dari susunan kawat baja yang dilas.</p>
<h1>3. Kekuatan dan Fleksibilitas</h1>
<p>Expanded Metal terkenal lebih kokoh terhadap tekanan dan benturan. Wiremesh unggul dalam distribusi beban pada beton sehingga cocok untuk konstruksi lantai atau jalan.</p>
<h1>4. Penggunaan di Lapangan</h1>
<p>Jika Anda ingin membuat pagar minimalis, railing, atau penutup ventilasi, Expanded Metal lebih cocok. Namun untuk pengecoran rumah atau dak, Wiremesh adalah pilihan yang lebih efisien.</p>
<h1>Mana yang Lebih Cocok?</h1>
<p>Jawabannya tergantung kebutuhan proyek Anda. Untuk struktur beton, Wiremesh jelas lebih tepat. Tetapi jika fokus pada keamanan, tampilan industrial, atau sirkulasi udara, Expanded Metal lebih unggul.</p>
<p>Bagi pemilik rumah atau proyek kecil, memilih material yang tepat bisa membantu menghemat biaya sekaligus membuat bangunan lebih awet. Karena itu, jangan hanya melihat harga murah, tetapi juga fungsi materialnya.</p>
<p>Jika Anda masih ragu memilih Expanded Metal atau Wiremesh, Anda bisa berkonsultasi langsung dengan <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> agar mendapatkan material yang sesuai kebutuhan proyek dan budget Anda.</p>',
                'image_path' => '/blog/perbedaan-expanded-metal-dan-wiremesh-mana-yang-lebih-cocok.jpg',
                'category' => null,
                'published_at' => '2026-05-19 17:34:23',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Jenis-Jenis Triplek Berdasarkan Ketebalan dan Lebarnya',
                'slug' => '2026/05/20/jenis-jenis-triplek-berdasarkan-ketebalan-dan-lebarnya',
                'content' => '<p><img class="alignnone size-full wp-image-4400" src="/assets/blog/jenis-jenis-triplek-berdasarkan-ketebalan-dan-lebarnya.jpg" alt="" width="1000" height="700" /></p>
<p>Saat memilih material bangunan atau furnitur, triplek menjadi salah satu bahan yang paling sering digunakan karena praktis, kuat, dan mudah dibentuk. Namun, masih banyak orang awam yang bingung menentukan ukuran triplek yang cocok untuk kebutuhan mereka. Padahal, memahami ketebalan dan lebar triplek bisa membantu menghemat biaya sekaligus membuat hasil pekerjaan lebih maksimal.</p>
<p>Sebagai toko bahan bangunan terpercaya, <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> menyediakan berbagai pilihan triplek dengan ukuran lengkap untuk kebutuhan rumah tangga hingga proyek konstruksi.</p>
<p><strong><span dir="auto">Baca juga:</span></strong></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/"><span dir="auto">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/"><span dir="auto">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/"><span dir="auto">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</span></a></span></p>
<h2>Jenis Triplek Berdasarkan Ketebalan</h2>
<p>Ketebalan triplek sangat memengaruhi kekuatan dan fungsi penggunaannya. Berikut beberapa ukuran yang paling umum di pasaran:</p>
<h3>Triplek 3 mm - 6 mm</h3>
<p>Triplek tipis biasanya digunakan untuk bagian dekoratif atau pelapis. Contohnya untuk backing lemari, kerajinan kayu, hingga partisi ringan. Karena ringan dan fleksibel, jenis ini mudah dipotong dan dibentuk.</p>
<h3>Triplek 9 mm</h3>
<p>Ukuran ini cukup populer untuk kebutuhan interior rumah seperti rak sederhana, kabinet kecil, atau dinding partisi. Ketebalan 9 mm dianggap pas karena tidak terlalu berat namun tetap kokoh.</p>
<h3>Triplek 12 mm - 15 mm</h3>
<p>Jenis triplek tebal sering digunakan untuk furnitur, meja, kitchen set, hingga kebutuhan konstruksi ringan. Semakin tebal triplek, semakin kuat daya tahannya terhadap beban.</p>
<h3>Triplek 18 mm</h3>
<p>Triplek dengan ketebalan ini cocok untuk proyek yang membutuhkan kekuatan ekstra, misalnya lantai sementara, panggung, atau meja kerja berat.</p>
<h2>Ukuran Lebar Triplek yang Umum Digunakan</h2>
<p>Selain ketebalan, ukuran lebar juga penting diperhatikan agar proses pemasangan lebih efisien dan minim sambungan. Ukuran standar triplek di Indonesia umumnya adalah 122 cm x 244 cm.</p>
<p>Ukuran tersebut dipilih karena praktis digunakan untuk berbagai kebutuhan, mulai dari pembuatan lemari hingga pelapis dinding. Namun, beberapa proyek tertentu juga membutuhkan ukuran custom agar lebih sesuai dengan desain ruangan.</p>
<h2>Kenapa Memilih Ukuran Triplek yang Tepat Itu Penting?</h2>
<p>Banyak orang fokus pada harga tanpa mempertimbangkan ukuran yang dibutuhkan. Akibatnya, material jadi terbuang atau hasil akhir kurang rapi. Triplek yang terlalu tipis bisa cepat melengkung, sedangkan yang terlalu tebal justru membuat biaya membengkak.</p>
<p>Karena itu, penting memilih triplek berdasarkan fungsi penggunaannya. Untuk dekorasi cukup gunakan triplek tipis, sedangkan furnitur dan konstruksi sebaiknya memakai ukuran yang lebih tebal dan kuat.</p>
<h2>Kesimpulan</h2>
<p>Memahami jenis-jenis triplek berdasarkan ketebalan dan lebar membantu Anda menentukan material yang tepat sesuai kebutuhan. Mulai dari triplek tipis untuk dekorasi hingga triplek tebal untuk furnitur dan proyek bangunan, semuanya memiliki fungsi masing-masing.</p>
<p>Butuh triplek berkualitas dengan ukuran lengkap dan harga kompetitif? Kunjungi <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> dan temukan pilihan material terbaik untuk proyek Anda.</p>',
                'description' => '<p></p>
<p>Saat memilih material bangunan atau furnitur, triplek menjadi salah satu bahan yang paling sering digunakan karena praktis, kuat, dan mudah dibentuk. Namun, masih banyak orang awam yang bingung menentukan ukuran triplek yang cocok untuk kebutuhan mereka. Padahal, memahami ketebalan dan lebar triplek bisa membantu menghemat biaya sekaligus membuat hasil pekerjaan lebih maksimal.</p>
<p>Sebagai toko bahan bangunan terpercaya, <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> menyediakan berbagai pilihan triplek dengan ukuran lengkap untuk kebutuhan rumah tangga hingga proyek konstruksi.</p>
<p><strong>Baca juga:</strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</a></p>
<h1>Jenis Triplek Berdasarkan Ketebalan</h1>
<p>Ketebalan triplek sangat memengaruhi kekuatan dan fungsi penggunaannya. Berikut beberapa ukuran yang paling umum di pasaran:</p>
<h1>Triplek 3 mm - 6 mm</h1>
<p>Triplek tipis biasanya digunakan untuk bagian dekoratif atau pelapis. Contohnya untuk backing lemari, kerajinan kayu, hingga partisi ringan. Karena ringan dan fleksibel, jenis ini mudah dipotong dan dibentuk.</p>
<h1>Triplek 9 mm</h1>
<p>Ukuran ini cukup populer untuk kebutuhan interior rumah seperti rak sederhana, kabinet kecil, atau dinding partisi. Ketebalan 9 mm dianggap pas karena tidak terlalu berat namun tetap kokoh.</p>
<h1>Triplek 12 mm - 15 mm</h1>
<p>Jenis triplek tebal sering digunakan untuk furnitur, meja, kitchen set, hingga kebutuhan konstruksi ringan. Semakin tebal triplek, semakin kuat daya tahannya terhadap beban.</p>
<h1>Triplek 18 mm</h1>
<p>Triplek dengan ketebalan ini cocok untuk proyek yang membutuhkan kekuatan ekstra, misalnya lantai sementara, panggung, atau meja kerja berat.</p>
<h1>Ukuran Lebar Triplek yang Umum Digunakan</h1>
<p>Selain ketebalan, ukuran lebar juga penting diperhatikan agar proses pemasangan lebih efisien dan minim sambungan. Ukuran standar triplek di Indonesia umumnya adalah 122 cm x 244 cm.</p>
<p>Ukuran tersebut dipilih karena praktis digunakan untuk berbagai kebutuhan, mulai dari pembuatan lemari hingga pelapis dinding. Namun, beberapa proyek tertentu juga membutuhkan ukuran custom agar lebih sesuai dengan desain ruangan.</p>
<h1>Kenapa Memilih Ukuran Triplek yang Tepat Itu Penting?</h1>
<p>Banyak orang fokus pada harga tanpa mempertimbangkan ukuran yang dibutuhkan. Akibatnya, material jadi terbuang atau hasil akhir kurang rapi. Triplek yang terlalu tipis bisa cepat melengkung, sedangkan yang terlalu tebal justru membuat biaya membengkak.</p>
<p>Karena itu, penting memilih triplek berdasarkan fungsi penggunaannya. Untuk dekorasi cukup gunakan triplek tipis, sedangkan furnitur dan konstruksi sebaiknya memakai ukuran yang lebih tebal dan kuat.</p>
<h1>Kesimpulan</h1>
<p>Memahami jenis-jenis triplek berdasarkan ketebalan dan lebar membantu Anda menentukan material yang tepat sesuai kebutuhan. Mulai dari triplek tipis untuk dekorasi hingga triplek tebal untuk furnitur dan proyek bangunan, semuanya memiliki fungsi masing-masing.</p>
<p>Butuh triplek berkualitas dengan ukuran lengkap dan harga kompetitif? Kunjungi <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> dan temukan pilihan material terbaik untuk proyek Anda.</p>',
                'image_path' => '/blog/jenis-jenis-triplek-berdasarkan-ketebalan-dan-lebarnya.jpg',
                'category' => null,
                'published_at' => '2026-05-20 16:57:53',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Tips Memilih Triplek Berkualitas: Perhatikan Lebar dan Ketebalannya',
                'slug' => '2026/05/20/tips-memilih-triplek-berkualitas-perhatikan-lebar-dan-ketebalannya',
                'content' => '<p><img class="alignnone size-full wp-image-4404" src="/assets/blog/tips-memilih-triplek-berkualitas-perhatikan-lebar-dan-ketebalannya.jpg" alt="" width="1000" height="700" /></p>
<p>Triplek menjadi material favorit untuk berbagai kebutuhan, mulai dari furnitur rumah, rak, kitchen set, hingga proyek bangunan ringan. Harganya relatif terjangkau dan mudah ditemukan, tetapi memilih triplek tidak boleh asal murah. Jika salah pilih, triplek bisa cepat melengkung, rapuh, bahkan rusak sebelum waktunya.</p>
<p>Agar tidak salah beli, ada beberapa hal penting yang perlu diperhatikan sebelum memilih triplek. <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> menghadirkan berbagai pilihan triplek berkualitas yang cocok untuk kebutuhan rumah maupun proyek profesional.</p>
<p><strong><span dir="auto">Baca juga:</span></strong></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/"><span dir="auto">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/"><span dir="auto">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/"><span dir="auto">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</span></a></span></p>
<h2>Perhatikan Ketebalan Triplek</h2>
<p>Ketebalan adalah faktor utama yang menentukan kekuatan triplek. Semakin tebal triplek, biasanya semakin kuat menahan beban.</p>
<h3>Triplek Tipis untuk Dekorasi</h3>
<p>Triplek 3 mm hingga 6 mm cocok digunakan untuk kebutuhan ringan seperti pelapis dinding, kerajinan, atau bagian belakang lemari. Jenis ini lebih ringan dan mudah dipotong.</p>
<h3>Triplek Sedang untuk Interior Rumah</h3>
<p>Untuk rak, kabinet, atau partisi ruangan, triplek 9 mm hingga 12 mm menjadi pilihan yang cukup ideal karena seimbang antara kekuatan dan bobotnya.</p>
<h3>Triplek Tebal untuk Beban Berat</h3>
<p>Jika digunakan untuk meja, kitchen set, atau proyek konstruksi ringan, sebaiknya pilih triplek 15 mm hingga 18 mm agar lebih kokoh dan tahan lama.</p>
<h2>Cek Ukuran Lebar Triplek</h2>
<p>Selain ketebalan, ukuran lebar juga penting agar pemasangan lebih efisien. Triplek standar biasanya memiliki ukuran 122 cm x 244 cm. Ukuran ini cocok untuk berbagai kebutuhan rumah tangga dan proyek bangunan.</p>
<p>Memilih ukuran yang tepat membantu mengurangi sambungan berlebih sehingga hasil akhir terlihat lebih rapi dan profesional.</p>
<h2>Perhatikan Permukaan dan Lapisan Triplek</h2>
<p>Triplek berkualitas umumnya memiliki permukaan yang halus, rata, dan tidak bergelombang. Hindari triplek yang terlihat retak, berlubang, atau memiliki lapisan yang mudah terkelupas karena dapat memengaruhi daya tahan material.</p>
<p>Jika memungkinkan, pilih triplek dengan lapisan finishing yang baik agar lebih tahan terhadap kelembapan dan perubahan suhu.</p>
<h2>Sesuaikan dengan Kebutuhan dan Budget</h2>
<p>Tidak semua proyek membutuhkan triplek paling tebal atau paling mahal. Yang terpenting adalah menyesuaikan spesifikasi dengan kebutuhan penggunaan. Dengan memilih ukuran dan kualitas yang tepat, Anda bisa mendapatkan hasil yang lebih awet tanpa mengeluarkan biaya berlebihan.</p>
<h2>Kesimpulan</h2>
<p>Memilih triplek berkualitas tidak hanya soal harga, tetapi juga soal ketebalan, lebar, dan kondisi materialnya. Dengan memahami fungsi setiap ukuran triplek, Anda bisa mendapatkan hasil bangunan atau furnitur yang lebih kuat dan tahan lama.</p>
<p>Temukan berbagai pilihan triplek berkualitas untuk kebutuhan rumah dan proyek Anda hanya di <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span>.</p>',
                'description' => '<p></p>
<p>Triplek menjadi material favorit untuk berbagai kebutuhan, mulai dari furnitur rumah, rak, kitchen set, hingga proyek bangunan ringan. Harganya relatif terjangkau dan mudah ditemukan, tetapi memilih triplek tidak boleh asal murah. Jika salah pilih, triplek bisa cepat melengkung, rapuh, bahkan rusak sebelum waktunya.</p>
<p>Agar tidak salah beli, ada beberapa hal penting yang perlu diperhatikan sebelum memilih triplek. <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> menghadirkan berbagai pilihan triplek berkualitas yang cocok untuk kebutuhan rumah maupun proyek profesional.</p>
<p><strong>Baca juga:</strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</a></p>
<h1>Perhatikan Ketebalan Triplek</h1>
<p>Ketebalan adalah faktor utama yang menentukan kekuatan triplek. Semakin tebal triplek, biasanya semakin kuat menahan beban.</p>
<h1>Triplek Tipis untuk Dekorasi</h1>
<p>Triplek 3 mm hingga 6 mm cocok digunakan untuk kebutuhan ringan seperti pelapis dinding, kerajinan, atau bagian belakang lemari. Jenis ini lebih ringan dan mudah dipotong.</p>
<h1>Triplek Sedang untuk Interior Rumah</h1>
<p>Untuk rak, kabinet, atau partisi ruangan, triplek 9 mm hingga 12 mm menjadi pilihan yang cukup ideal karena seimbang antara kekuatan dan bobotnya.</p>
<h1>Triplek Tebal untuk Beban Berat</h1>
<p>Jika digunakan untuk meja, kitchen set, atau proyek konstruksi ringan, sebaiknya pilih triplek 15 mm hingga 18 mm agar lebih kokoh dan tahan lama.</p>
<h1>Cek Ukuran Lebar Triplek</h1>
<p>Selain ketebalan, ukuran lebar juga penting agar pemasangan lebih efisien. Triplek standar biasanya memiliki ukuran 122 cm x 244 cm. Ukuran ini cocok untuk berbagai kebutuhan rumah tangga dan proyek bangunan.</p>
<p>Memilih ukuran yang tepat membantu mengurangi sambungan berlebih sehingga hasil akhir terlihat lebih rapi dan profesional.</p>
<h1>Perhatikan Permukaan dan Lapisan Triplek</h1>
<p>Triplek berkualitas umumnya memiliki permukaan yang halus, rata, dan tidak bergelombang. Hindari triplek yang terlihat retak, berlubang, atau memiliki lapisan yang mudah terkelupas karena dapat memengaruhi daya tahan material.</p>
<p>Jika memungkinkan, pilih triplek dengan lapisan finishing yang baik agar lebih tahan terhadap kelembapan dan perubahan suhu.</p>
<h1>Sesuaikan dengan Kebutuhan dan Budget</h1>
<p>Tidak semua proyek membutuhkan triplek paling tebal atau paling mahal. Yang terpenting adalah menyesuaikan spesifikasi dengan kebutuhan penggunaan. Dengan memilih ukuran dan kualitas yang tepat, Anda bisa mendapatkan hasil yang lebih awet tanpa mengeluarkan biaya berlebihan.</p>
<h1>Kesimpulan</h1>
<p>Memilih triplek berkualitas tidak hanya soal harga, tetapi juga soal ketebalan, lebar, dan kondisi materialnya. Dengan memahami fungsi setiap ukuran triplek, Anda bisa mendapatkan hasil bangunan atau furnitur yang lebih kuat dan tahan lama.</p>
<p>Temukan berbagai pilihan triplek berkualitas untuk kebutuhan rumah dan proyek Anda hanya di <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a>.</p>',
                'image_path' => '/blog/tips-memilih-triplek-berkualitas-perhatikan-lebar-dan-ketebalannya.jpg',
                'category' => null,
                'published_at' => '2026-05-20 16:59:39',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Downlight Lingkaran 7,5 Watt Putih (INLite)',
                'slug' => '2026/05/20/lampu-downlight-lingkaran-75-watt-putih-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-downlight-lingkaran-75-watt-putih-inlite.jpg" alt="" class="wp-image-5024" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Downlight Lingkaran 7,5 Watt Putih (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu downlight LED berbentuk kotak dengan desain slim dan modern yang dirancang untuk memberikan pencahayaan interior yang rapi, minimalis, dan elegan. Dapat dipasang secara tanam (inbow) maupun tempel (outbow) pada plafon, sehingga fleksibel untuk berbagai kebutuhan desain ruangan. Menghasilkan cahaya yang terang dan merata dengan sudut pancar yang lebar, lampu ini mampu memberikan pencahayaan optimal tanpa menimbulkan bayangan berlebih, sekaligus tetap hemat energi dengan konsumsi listrik yang efisien. Sangat cocok digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar yang membutuhkan pencahayaan modern dan fungsional.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-downlight-lingkaran-75-watt-putih-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:09:51',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Jalanan 100 Watt (INLite)',
                'slug' => '2026/05/20/lampu-jalanan-100-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-jalanan-100-watt-inlite.jpg" alt="" class="wp-image-4656" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Jalanan 100 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-jalanan-100-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:10:15',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Jalanan 150 Watt (INLite)',
                'slug' => '2026/05/20/lampu-jalanan-150-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-jalanan-150-watt-inlite.jpg" alt="" class="wp-image-4657" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Jalanan 150 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-jalanan-150-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:10:59',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Jalanan 50 Watt (INLite)',
                'slug' => '2026/05/20/lampu-jalanan-50-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-jalanan-50-watt-inlite.jpg" alt="" class="wp-image-4655" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Jalanan 50 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-jalanan-50-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:11:19',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu LED Tabung 10 Watt (INLite)',
                'slug' => '2026/05/20/lampu-led-tabung-10-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-led-tabung-10-watt-inlite.jpg" alt="" class="wp-image-4659" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu LED Tabung 10 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-led-tabung-10-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:11:39',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu LED Tabung 14 Watt (INLite)',
                'slug' => '2026/05/20/lampu-led-tabung-14-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-led-tabung-14-watt-inlite.jpg" alt="" class="wp-image-4660" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu LED Tabung 14 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-led-tabung-14-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:11:57',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu LED Tabung 20 Watt (INLite)',
                'slug' => '2026/05/20/lampu-led-tabung-20-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-led-tabung-20-watt-inlite.jpg" alt="" class="wp-image-4661" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu LED Tabung 20 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-led-tabung-20-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:12:28',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu LED Tabung 5 Watt (INLite)',
                'slug' => '2026/05/20/lampu-led-tabung-5-watt-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-led-tabung-5-watt-inlite.jpg" alt="" class="wp-image-4658" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu LED Tabung 5 Watt (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>
</div>
</div>',
                'description' => '<p>Lampu jalan LED dengan desain kokoh dan modern yang dirancang khusus untuk kebutuhan penerangan area luar ruang dengan tingkat ketahanan tinggi. Dilengkapi proteksi tahan cuaca standar IP65, lampu ini mampu beroperasi secara optimal dalam berbagai kondisi lingkungan seperti hujan, panas, dan debu. Menghasilkan cahaya yang terang, stabil, dan merata dengan efisiensi energi yang tinggi, sehingga memberikan penghematan biaya operasional serta umur pakai yang lebih panjang. Sangat ideal digunakan untuk penerangan jalan umum (PJU), area parkir, kawasan industri, perumahan, hingga berbagai proyek infrastruktur dan area publik skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan luar ruang yang kuat, efisien, dan terpercaya untuk mendukung kebutuhan infrastruktur modern di lapangan.</p>',
                'image_path' => '/blog/lampu-led-tabung-5-watt-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:13:12',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 12 Watt Inbow Kotak (INLite)',
                'slug' => '2026/05/20/lampu-plafon-12-watt-inbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-12-watt-inbow-kotak-inlite.jpg" alt="" class="wp-image-4914" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 12 Watt Inbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-12-watt-inbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:13:36',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 12 Watt Inbow Lingkaran (INLite)',
                'slug' => '2026/05/20/lampu-plafon-12-watt-inbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-12-watt-inbow-lingkaran-inlite.jpg" alt="" class="wp-image-4913" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 12 Watt Inbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-12-watt-inbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:13:54',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 12 Watt Outbow Kotak (INLite)',
                'slug' => '2026/05/20/lampu-plafon-12-watt-outbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-12-watt-outbow-kotak-inlite.jpg" alt="" class="wp-image-4912" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 12 Watt Outbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tempel (outbow) berbentuk kotak dengan desain modern yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tempel (outbow) berbentuk kotak dengan desain modern yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-12-watt-outbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:15:06',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 12 Watt Outbow Lingkaran (INLite)',
                'slug' => '2026/05/20/lampu-plafon-12-watt-outbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-12-watt-outbow-lingkaran-inlite.jpg" alt="" class="wp-image-4911" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 12 Watt Outbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tempel (outbow) berbentuk lingkaran dengan desain simetris dan modern yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tempel (outbow) berbentuk lingkaran dengan desain simetris dan modern yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-12-watt-outbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-20 22:15:48',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => '3 Jenis Scaffolding yang Umum Digunakan di Proyek Bangunan',
                'slug' => '2026/05/21/3-jenis-scaffolding-yang-umum-digunakan-di-proyek-bangunan',
                'content' => '<p><img class="alignnone size-full wp-image-5212" src="/assets/blog/3-jenis-scaffolding-yang-umum-digunakan-di-proyek-bangunan.jpg" alt="" width="1000" height="700" /></p>
<p>Dalam dunia konstruksi, scaffolding atau perancah menjadi salah satu komponen penting yang sering digunakan untuk membantu proses pekerjaan di ketinggian. Mulai dari pembangunan rumah, ruko, gedung bertingkat, hingga renovasi, penggunaan scaffolding membantu pekerja bekerja lebih aman, stabil, dan efisien.</p>
<p>Bagi orang awam, scaffolding mungkin terlihat sama saja. Padahal, ada beberapa jenis scaffolding yang memiliki fungsi berbeda tergantung kebutuhan proyek. Memahami jenisnya bisa membantu Anda memilih material konstruksi yang tepat dan lebih hemat biaya.</p>
<p><strong><span dir="auto">Baca juga:</span></strong></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/"><span dir="auto">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/"><span dir="auto">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</span></a></span></p>
<p><span style="text-decoration: underline"><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/"><span dir="auto">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</span></a></span></p>
<h2>Apa Itu Scaffolding?</h2>
<p>Scaffolding adalah struktur sementara yang digunakan untuk menopang pekerja dan material selama proses konstruksi berlangsung. Selain meningkatkan keamanan kerja, scaffolding juga mempercepat proses pembangunan karena akses kerja menjadi lebih mudah.</p>
<p>Saat ini, penggunaan scaffolding modern lebih diminati dibanding metode tradisional karena pemasangannya lebih praktis dan kuat.</p>
<h2>Jenis Scaffolding yang Paling Umum Digunakan</h2>
<h3>1. Frame Scaffolding</h3>
<p>Frame scaffolding merupakan jenis yang paling sering ditemukan pada proyek rumah dan bangunan umum. Bentuknya menyerupai rangka besi yang disusun vertikal dan horizontal.</p>
<p>Keunggulan frame scaffolding adalah pemasangannya cepat, mudah dipindahkan, dan cocok untuk pekerjaan dinding maupun pengecatan. Jenis ini juga relatif ekonomis sehingga banyak dipilih kontraktor skala kecil hingga menengah.</p>
<h3>2. Ringlock Scaffolding</h3>
<p>Ringlock scaffolding biasanya digunakan pada proyek gedung bertingkat atau konstruksi skala besar. Sistem pengunci berbentuk lingkaran membuat struktur lebih stabil dan kuat menopang beban berat.</p>
<p>Jenis scaffolding ini cocok untuk proyek yang membutuhkan tingkat keamanan tinggi dan fleksibilitas pemasangan di berbagai medan.</p>
<h3>3. Mobile Scaffolding</h3>
<p>Sesuai namanya, mobile scaffolding dilengkapi roda sehingga mudah dipindahkan tanpa perlu bongkar pasang. Jenis ini sering digunakan untuk pekerjaan interior, plafon, instalasi listrik, atau maintenance gedung.</p>
<p>Mobile scaffolding sangat membantu pekerjaan yang membutuhkan mobilitas tinggi dalam area yang luas.</p>
<h2>Faktor Penting Saat Memilih Scaffolding</h2>
<p>Sebelum membeli atau menyewa scaffolding, ada beberapa hal yang perlu diperhatikan:</p>
<ul>
<li>Tinggi area kerja</li>
<li>Beban yang akan ditopang</li>
<li>Jenis proyek bangunan</li>
<li>Standar keamanan material</li>
<li>Kemudahan pemasangan</li>
</ul>
<p>Menggunakan scaffolding berkualitas bukan hanya soal efisiensi, tetapi juga keselamatan pekerja di lapangan.</p>
<h2>Pilih Material Konstruksi Berkualitas di Yen Bangunan</h2>
<p>Jika Anda sedang mencari kebutuhan proyek seperti scaffolding, besi, semen, hingga material bangunan lainnya, <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> menyediakan berbagai pilihan produk berkualitas untuk kebutuhan konstruksi rumah maupun proyek besar.</p>
<p>Dengan material yang tepat, pekerjaan konstruksi bisa berjalan lebih aman, cepat, dan tahan lama. Hubungi tim <span class=""><a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a></span> sekarang untuk mendapatkan informasi produk dan penawaran terbaik.</p>',
                'description' => '<p></p>
<p>Dalam dunia konstruksi, scaffolding atau perancah menjadi salah satu komponen penting yang sering digunakan untuk membantu proses pekerjaan di ketinggian. Mulai dari pembangunan rumah, ruko, gedung bertingkat, hingga renovasi, penggunaan scaffolding membantu pekerja bekerja lebih aman, stabil, dan efisien.</p>
<p>Bagi orang awam, scaffolding mungkin terlihat sama saja. Padahal, ada beberapa jenis scaffolding yang memiliki fungsi berbeda tergantung kebutuhan proyek. Memahami jenisnya bisa membantu Anda memilih material konstruksi yang tepat dan lebih hemat biaya.</p>
<p><strong>Baca juga:</strong></p>
<p><a href="https://yenbangunan.com/2025/08/05/rekomendasi-toko-bangunan-cikarang-dengan-layanan-24-jam-dan-tepat-waktu/">Rekomendasi Toko Bangunan Cikarang dengan Layanan 24 Jam dan Tepat Waktu</a></p>
<p><a href="https://yenbangunan.com/2025/10/27/toko-besi-cikarang-terbaik-hubungi-yen-bangunan-di-081315147952/">Toko Besi Cikarang Terbaik: Hubungi Yen Bangunan di 081315147952</a></p>
<p><a href="https://yenbangunan.com/2025/09/30/toko-listrik-cikarang-solusi-lengkap-untuk-kebutuhan-instalasi/">Toko Listrik Cikarang – Solusi Lengkap untuk Kebutuhan Instalasi</a></p>
<h1>Apa Itu Scaffolding?</h1>
<p>Scaffolding adalah struktur sementara yang digunakan untuk menopang pekerja dan material selama proses konstruksi berlangsung. Selain meningkatkan keamanan kerja, scaffolding juga mempercepat proses pembangunan karena akses kerja menjadi lebih mudah.</p>
<p>Saat ini, penggunaan scaffolding modern lebih diminati dibanding metode tradisional karena pemasangannya lebih praktis dan kuat.</p>
<h1>Jenis Scaffolding yang Paling Umum Digunakan</h1>
<h1>1. Frame Scaffolding</h1>
<p>Frame scaffolding merupakan jenis yang paling sering ditemukan pada proyek rumah dan bangunan umum. Bentuknya menyerupai rangka besi yang disusun vertikal dan horizontal.</p>
<p>Keunggulan frame scaffolding adalah pemasangannya cepat, mudah dipindahkan, dan cocok untuk pekerjaan dinding maupun pengecatan. Jenis ini juga relatif ekonomis sehingga banyak dipilih kontraktor skala kecil hingga menengah.</p>
<h1>2. Ringlock Scaffolding</h1>
<p>Ringlock scaffolding biasanya digunakan pada proyek gedung bertingkat atau konstruksi skala besar. Sistem pengunci berbentuk lingkaran membuat struktur lebih stabil dan kuat menopang beban berat.</p>
<p>Jenis scaffolding ini cocok untuk proyek yang membutuhkan tingkat keamanan tinggi dan fleksibilitas pemasangan di berbagai medan.</p>
<h1>3. Mobile Scaffolding</h1>
<p>Sesuai namanya, mobile scaffolding dilengkapi roda sehingga mudah dipindahkan tanpa perlu bongkar pasang. Jenis ini sering digunakan untuk pekerjaan interior, plafon, instalasi listrik, atau maintenance gedung.</p>
<p>Mobile scaffolding sangat membantu pekerjaan yang membutuhkan mobilitas tinggi dalam area yang luas.</p>
<h1>Faktor Penting Saat Memilih Scaffolding</h1>
<p>Sebelum membeli atau menyewa scaffolding, ada beberapa hal yang perlu diperhatikan:</p>
<ul>
<li>Tinggi area kerja</li>
<li>Beban yang akan ditopang</li>
<li>Jenis proyek bangunan</li>
<li>Standar keamanan material</li>
<li>Kemudahan pemasangan</li>
</ul>
<p>Menggunakan scaffolding berkualitas bukan hanya soal efisiensi, tetapi juga keselamatan pekerja di lapangan.</p>
<h1>Pilih Material Konstruksi Berkualitas di Yen Bangunan</h1>
<p>Jika Anda sedang mencari kebutuhan proyek seperti scaffolding, besi, semen, hingga material bangunan lainnya, <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> menyediakan berbagai pilihan produk berkualitas untuk kebutuhan konstruksi rumah maupun proyek besar.</p>
<p>Dengan material yang tepat, pekerjaan konstruksi bisa berjalan lebih aman, cepat, dan tahan lama. Hubungi tim <a class="decorated-link" href="https://yenbangunan.com?utm_source=chatgpt.com" target="_blank" rel="noopener">Yen Bangunan</a> sekarang untuk mendapatkan informasi produk dan penawaran terbaik.</p>',
                'image_path' => '/blog/3-jenis-scaffolding-yang-umum-digunakan-di-proyek-bangunan.jpg',
                'category' => null,
                'published_at' => '2026-05-21 16:41:23',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 18 Watt Inbow Kotak (INLite)',
                'slug' => '2026/05/21/lampu-plafon-18-watt-inbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-18-watt-inbow-kotak-inlite.jpg" alt="" class="wp-image-4910" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 18 Watt Inbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-18-watt-inbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:05:29',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 18 Watt Inbow Lingkaran (INLite)',
                'slug' => '2026/05/21/lampu-plafon-18-watt-inbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-18-watt-inbow-lingkaran-inlite.jpg" alt="" class="wp-image-4909" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 18 Watt Inbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain slim dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain slim dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-18-watt-inbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:05:49',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 18 Watt Outbow Kotak (INLite)',
                'slug' => '2026/05/21/lampu-plafon-18-watt-outbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-18-watt-outbow-kotak-inlite.jpg" alt="" class="wp-image-4908" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 18 Watt Outbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tempel (outbow) berbentuk lingkaran dengan desain tipis, modern, dan minimalis yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tempel (outbow) berbentuk lingkaran dengan desain tipis, modern, dan minimalis yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-18-watt-outbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:06:09',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 18 Watt Outbow Lingkaran (INLite)',
                'slug' => '2026/05/21/lampu-plafon-18-watt-outbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-18-watt-outbow-lingkaran-inlite.jpg" alt="" class="wp-image-4907" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 18 Watt Outbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-18-watt-outbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:06:29',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 6 Watt Inbow Kotak (INLite)',
                'slug' => '2026/05/21/lampu-plafon-6-watt-inbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-6-watt-inbow-kotak-inlite.jpg" alt="" class="wp-image-4920" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 6 Watt Inbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-6-watt-inbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:06:50',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 6 Watt Inbow Lingkaran (INLite)',
                'slug' => '2026/05/21/lampu-plafon-6-watt-inbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-6-watt-inbow-lingkaran-inlite.jpg" alt="" class="wp-image-4919" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 6 Watt Inbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain slim dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk lingkaran dengan desain slim dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan estetik. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih dan elegan tanpa menonjol ke bawah permukaan plafon. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, sangat cocok sebagai penerangan utama yang nyaman di berbagai area ruangan. Ideal digunakan untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang mengutamakan kombinasi antara efisiensi, estetika, dan fungsi.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-6-watt-inbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:07:12',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 6 Watt Outbow Kotak (INLite)',
                'slug' => '2026/05/21/lampu-plafon-6-watt-outbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-6-watt-outbow-kotak-inlite.jpg" alt="" class="wp-image-4918" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 6 Watt Outbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tempel (outbow) berbentuk lingkaran dengan desain tipis, modern, dan minimalis yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tempel (outbow) berbentuk lingkaran dengan desain tipis, modern, dan minimalis yang dapat dipasang langsung di permukaan plafon tanpa perlu melubangi, sehingga proses instalasi lebih mudah dan praktis. Cocok digunakan untuk berbagai area yang tidak memungkinkan pemasangan tanam (inbow), atau sebagai pilihan pencahayaan tambahan yang fleksibel. Menghasilkan cahaya terang merata dengan sudut pancar lebar dan konsumsi listrik yang efisien, sehingga ideal untuk rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai area interior skala besar.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan pembangunan interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-6-watt-outbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:07:32',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 6 Watt Outbow Lingkaran (INLite)',
                'slug' => '2026/05/21/lampu-plafon-6-watt-outbow-lingkaran-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-6-watt-outbow-lingkaran-inlite.jpg" alt="" class="wp-image-4917" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 6 Watt Outbow Lingkaran (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-6-watt-outbow-lingkaran-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:07:52',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Lampu Plafon 9 Watt Inbow Kotak (INLite)',
                'slug' => '2026/05/21/lampu-plafon-9-watt-inbow-kotak-inlite',
                'content' => '<div class="wp-block-group alignwide product-content is-nowrap is-layout-flex wp-container-core-group-is-layout-794e3cfa wp-block-group-is-layout-flex">
<figure class="wp-block-image size-full wp-container-content-9e2f13cb wp-duotone-unset-1"><img loading="lazy" width="1000" height="1000" src="/assets/blog/lampu-plafon-9-watt-inbow-kotak-inlite.jpg" alt="" class="wp-image-4916" style="object-fit:cover" /></figure>
<div class="wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
<div class="wp-block-jetpack-send-a-message whatsapp-product-desktop">
<div class="wp-block-jetpack-whatsapp-button whatsapp-button-desktop is-color-dark"><a class="whatsapp-block__button" href="https://api.whatsapp.com/send?phone=6281315147952&amp;text=Halo%20min%20Yen%20Bangunan%2C%20boleh%20saya%20tanya-tanya%20dulu%20seputar%20stok%20dan%20harga%20barangnya%3F" style="background-color:#25D366;color:#fff" target="_blank" rel="noopener noreferrer">Pesan Melalui Whatsapp</a></div>
</div>
<h2 class="wp-block-heading has-large-font-size">Lampu Plafon 9 Watt Inbow Kotak (INLite) &#8211; Yen Bangunan&nbsp;Cikarang</h2>
<hr class="wp-block-separator has-css-opacity has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color is-style-wide" />
<h2 class="wp-block-heading has-medium-font-size">Deskripsi Produk</h2>
<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia di Yen Bangunan Cikarang, penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>
</div>
</div>',
                'description' => '<p>Lampu plafon LED model tanam (inbow) berbentuk kotak dengan desain tipis dan minimalis yang dirancang untuk memberikan tampilan interior yang rapi, modern, dan elegan. Terpasang menyatu di dalam plafon sehingga menghasilkan kesan bersih tanpa mengganggu estetika ruangan. Menghasilkan cahaya terang yang merata dengan sudut pancar lebar, lampu ini sangat ideal sebagai penerangan utama yang nyaman di berbagai area. Cocok digunakan pada rumah tinggal, kantor, ruko, gedung komersial, hingga berbagai kebutuhan pencahayaan interior skala besar yang membutuhkan kombinasi antara efisiensi, fungsi, dan estetika.</p>
<p>Tersedia melalui penyedia material bangunan untuk kebutuhan proyek residensial, komersial, industri, dan konstruksi berskala besar dengan komitmen menghadirkan produk pencahayaan yang modern, efisien, dan berkualitas untuk mendukung kebutuhan desain interior masa kini.</p>',
                'image_path' => '/blog/lampu-plafon-9-watt-inbow-kotak-inlite.jpg',
                'category' => 'lampu-dan-kelistrikan',
                'published_at' => '2026-05-21 21:08:13',
                'author_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        DB::table('blogs')->upsert(
            $posts,
            ['slug'],
            ['title', 'content', 'description', 'image_path', 'category', 'published_at', 'author_id', 'updated_at']
        );
    }
}
