<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        // Run user seeder
        $this->call(UserSeeder::class);

        // Akun superadmin untuk /admin — idempotent, aman dipanggil tiap seed.
        $this->call(SuperAdminSeeder::class);

        // Run order seeder
        $this->call(OrderSeeder::class);

        // Run loyalty formula seeder
        $this->call(LoyaltyFormulaSeeder::class);

        // Run redeem item seeder
        $this->call(RedeemItemSeeder::class);

        // Run loyalty + redeem history seeder
        $this->call(LoyaltySeeder::class);

        // Run blog seeders (Blog dispatches every generated BlogPart*)
        $this->call(Blog::class);
    }
}
